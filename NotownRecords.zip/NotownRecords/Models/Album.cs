﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace NotownRecords.Models
{
    public class Album
    {
        // Unique Identifier Number
        public int ID { get; set; }
        public string Title { get; set; }
        [DataType(DataType.Date)]
        public DateTime CopyrightDate { get; set; }
        public string Format { get; set; }
        public int Identifier { get; set; }
        public Musician Producer { get; set; } 

        public ICollection<Song> Songs { get; set; }
    }
}
