﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NotownRecords.Models
{
    public class Instrument
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string MusicalKey { get; set; }
    }
}
