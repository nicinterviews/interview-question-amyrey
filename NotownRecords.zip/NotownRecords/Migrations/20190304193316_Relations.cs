﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NotownRecords.Migrations
{
    public partial class Relations : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "SongID",
                table: "Musician",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProducerID",
                table: "Album",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Musician_SongID",
                table: "Musician",
                column: "SongID");

            migrationBuilder.CreateIndex(
                name: "IX_Album_ProducerID",
                table: "Album",
                column: "ProducerID");

            migrationBuilder.AddForeignKey(
                name: "FK_Album_Musician_ProducerID",
                table: "Album",
                column: "ProducerID",
                principalTable: "Musician",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Musician_Song_SongID",
                table: "Musician",
                column: "SongID",
                principalTable: "Song",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Album_Musician_ProducerID",
                table: "Album");

            migrationBuilder.DropForeignKey(
                name: "FK_Musician_Song_SongID",
                table: "Musician");

            migrationBuilder.DropIndex(
                name: "IX_Musician_SongID",
                table: "Musician");

            migrationBuilder.DropIndex(
                name: "IX_Album_ProducerID",
                table: "Album");

            migrationBuilder.DropColumn(
                name: "SongID",
                table: "Musician");

            migrationBuilder.DropColumn(
                name: "ProducerID",
                table: "Album");
        }
    }
}
