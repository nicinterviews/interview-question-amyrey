﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace NotownRecords.Migrations
{
    public partial class AddressTakeTwo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Musician_Address_AddressID",
                table: "Musician");

            migrationBuilder.DropTable(
                name: "Address");

            migrationBuilder.DropIndex(
                name: "IX_Musician_AddressID",
                table: "Musician");

            migrationBuilder.DropColumn(
                name: "AddressID",
                table: "Musician");

            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "Musician",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PhoneNumber",
                table: "Musician",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Address",
                table: "Musician");

            migrationBuilder.DropColumn(
                name: "PhoneNumber",
                table: "Musician");

            migrationBuilder.AddColumn<int>(
                name: "AddressID",
                table: "Musician",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Address",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Address = table.Column<string>(nullable: true),
                    PhoneNumber = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Address", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Musician_AddressID",
                table: "Musician",
                column: "AddressID");

            migrationBuilder.AddForeignKey(
                name: "FK_Musician_Address_AddressID",
                table: "Musician",
                column: "AddressID",
                principalTable: "Address",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
