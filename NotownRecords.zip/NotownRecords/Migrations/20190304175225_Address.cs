﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NotownRecords.Migrations
{
    public partial class Address : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Musician_MusicianAddress_AddressID",
                table: "Musician");

            migrationBuilder.DropPrimaryKey(
                name: "PK_MusicianAddress",
                table: "MusicianAddress");

            migrationBuilder.RenameTable(
                name: "MusicianAddress",
                newName: "Address");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Address",
                table: "Address",
                column: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Musician_Address_AddressID",
                table: "Musician",
                column: "AddressID",
                principalTable: "Address",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Musician_Address_AddressID",
                table: "Musician");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Address",
                table: "Address");

            migrationBuilder.RenameTable(
                name: "Address",
                newName: "MusicianAddress");

            migrationBuilder.AddPrimaryKey(
                name: "PK_MusicianAddress",
                table: "MusicianAddress",
                column: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Musician_MusicianAddress_AddressID",
                table: "Musician",
                column: "AddressID",
                principalTable: "MusicianAddress",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
