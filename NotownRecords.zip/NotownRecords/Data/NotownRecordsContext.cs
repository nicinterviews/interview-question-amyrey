﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using NotownRecords.Models;

namespace NotownRecords.Models
{
    public class NotownRecordsContext : DbContext
    {
        public NotownRecordsContext (DbContextOptions<NotownRecordsContext> options)
            : base(options)
        {
        }

        public DbSet<NotownRecords.Models.Musician> Musician { get; set; }

        public DbSet<NotownRecords.Models.Instrument> Instrument { get; set; }

        public DbSet<NotownRecords.Models.Album> Album { get; set; }

        public DbSet<NotownRecords.Models.Song> Song { get; set; }
    }
}
